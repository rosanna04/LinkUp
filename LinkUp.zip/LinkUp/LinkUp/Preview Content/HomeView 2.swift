//
//  HomeView 2.swift
//  LinkUp
//
//  Created by Rosanna Petecca on 05/02/25.
//


import SwiftUI

struct HomeView: View {
    var body: some View {
        VStack {
            
            ScrollView {
                VStack {
                    VStack(spacing: 20) {
                        VStack(alignment: .leading) {
                            HStack(spacing: 10) {
                                ForEach(["Su", "Mo", "Tu", "We", "Th", "Fr"], id: \.self) { day in
                                    VStack {
                                        Text(day)
                                            .font(.system(size: 14, weight: .bold))
                                            .foregroundColor(.black)
                                        
                                        Text("\(randomDate(for: day))")
                                            .frame(width: 35, height: 35)
                                            .background(day == "Tu" ? Color(uiColor: UIColor(hex: "#AC94FF")).opacity(0.3) : Color.clear)
                                            .clipShape(Circle())
                                            .foregroundColor(.black)
                                    }
                                }
                            }
                            .padding(.horizontal)
                        }
                    }
                    
                    Text("MY HABITS")
                        .font(.system(size: 22, weight: .bold))
                        .foregroundStyle(Color(uiColor: UIColor(hex: "#5206c2")))
                        .padding(.top, 10)
                    
                    VStack(spacing: 15) {
                        HabitRow(icon: "bicycle", title: "Cycling", progress: 1482, total: 3000, unit: "m")
                        HabitRow(icon: "flame.fill", title: "Burn calorie", progress: 222, total: 500, unit: "cal")
                        HabitRow(icon: "drop.fill", title: "Drink Water", progress: 2, total: 2, unit: "l", isHighlighted: true)
                    }
                    .padding(.horizontal)
                    
                    Spacer()
                }
                .padding(.top, 20)
            }
            
            HStack {
                Spacer()
                TabLabel(title: "Add An Habit")
                Spacer()
                TabLabel(title: "Calendar")
                Spacer()
                TabLabel(title: "Friends")
                Spacer()
            }
            .padding()
        }
    }
}

struct HabitRow: View {
    var icon: String
    var title: String
    var progress: Int
    var total: Int
    var unit: String
    var isHighlighted: Bool = false

    var body: some View {
        HStack {
            Image(systemName: icon)
                .foregroundStyle(Color(uiColor: UIColor(hex: "#5206c2")))
                .font(.system(size: 20))

            Text(title)
                .font(.system(size: 18, weight: .bold)).foregroundStyle(Color(uiColor: UIColor(hex: "#5206c2")))
            
            Spacer()
            
            Text("\(progress)/\(total) \(unit)")
                .foregroundStyle(Color(uiColor: UIColor(hex: "#5206c2")))
        }
        .padding()
        .frame(maxWidth: .infinity, maxHeight: 500)
        .background((Color(uiColor: UIColor(hex: "AC94FF")).opacity(0.1)
        .cornerRadius(40)))
    }
}

struct TabLabel: View {
    var title: String

    var body: some View {
        Text(title)
            .font(.system(size: 14, weight: .bold))
            .foregroundStyle(Color(uiColor: UIColor(hex: "#5206c2")))
    }
}

func randomDate(for day: String) -> Int {
    let dates = ["Su": 2, "Mo": 3, "Tu": 4, "We": 5, "Th": 6, "Fr": 7]
    return dates[day] ?? 1
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
