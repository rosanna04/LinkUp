//
//  ChooseHabits.swift
//  LinkUp
//
//  Created by Rosanna Petecca on 03/02/25.
//

import SwiftUI

struct Habit {
    var title: String
    var icon: String
}

struct ChooseHabits: View {

    let habits = [
        Habit(title: "Walk", icon: "figure.walk"),
        Habit(title: "Drink water", icon: "waterbottle"),
        Habit(title: "Read a book", icon: "book"),
        Habit(title: "Cycling", icon: "figure.outdoor.cycle"),
        Habit(title: "Workout", icon: "dumbbell.fill"),
        Habit(title: "Study", icon: "book.closed.fill"),
        Habit(title: "Don't use devices", icon: "macbook.slash"),
        Habit(title: "Play videogames", icon: "gamecontroller")
        
        
    ]
    
    var body: some View {
            ScrollView {
                VStack(spacing: 20) {
                    Text("Choose a New Habit")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .padding(20)
                        .foregroundColor(Color(uiColor: UIColor(hex: "#5206c2"))).multilineTextAlignment(.center)
                    
                    ForEach(habits, id: \.title) { habit in
                        NavigationLink(destination: HabitDetailView(habit: habit)) {
                            habitRow(habit: habit)
                        }
                    }
                }
                .padding(20)
            }
            .padding(20)
    }
    
    func habitRow(habit: Habit) -> some View {
        HStack {
            Image(systemName: habit.icon)
                .font(.title2)
                .foregroundColor(Color(uiColor: UIColor(hex: "#5206c2")))
            
            Text(habit.title)
                .font(.title2)
                .fontWeight(.semibold)
                .foregroundColor(Color(uiColor: UIColor(hex: "#5206c2")))
            
            Spacer()
            
            Image(systemName: "plus")
                .font(.title2)
                .fontWeight(.semibold)
                .foregroundColor(Color(uiColor: UIColor(hex: "#5206c2")))
        }
        .padding()
        .frame(maxWidth: .infinity, minHeight: 70)
        .background(Color.gray.opacity(0.06).shadow(radius: 10))
        .cornerRadius(50)
    }
}


struct HabitDetailView: View {
    var habit: Habit
    
    @State private var selectedDate = Date()
    @State private var selectedTime = Date()
    
    var body: some View {
        
            VStack {
                Text("Set your habit").foregroundColor(Color(uiColor: UIColor(hex: "#5206c2")))
                    .font(.title)
                    .fontWeight(.bold)
                    .padding()
                
                HStack{
                    Image(systemName: habit.icon)
                        .font(.largeTitle)
                        .foregroundColor(Color(uiColor: UIColor(hex: "#5206c2")))
                    Text(habit.title).foregroundColor(Color(uiColor: UIColor(hex: "#5206c2")))
                        .font(.title)
                        .fontWeight(.semibold)
                }
                .padding()
                
                
                DatePicker("Choose a date", selection: $selectedDate, displayedComponents: .date)
                    .padding().fontWeight(.semibold)
                
                DatePicker("Choose a time", selection: $selectedTime, displayedComponents: .hourAndMinute).fontWeight(.semibold)
                    .padding()
                
                NavigationLink(destination: HabitChoosed()){
                    
                    VStack {
                        Spacer()
                        
                        NavigationLink(destination: HabitChoosed()) {
                            Text("Done")
                                .foregroundColor(.white)
                                .fontWeight(.bold)
                                .padding()
                                .frame(maxWidth: .infinity)
                                .background(Color(uiColor: UIColor(hex: "#5206c2")))
                                .cornerRadius(40)
                                .shadow(radius: 10)
                        }
                        
                        Spacer()
                    }
                    .padding()
                }
                .navigationTitle("Set Your Habit")
                .padding()
            }
        }
}

#Preview {
    NavigationStack {
        HabitDetailView(habit: Habit(title: "Walk", icon: "figure.walk"))
    }
}
