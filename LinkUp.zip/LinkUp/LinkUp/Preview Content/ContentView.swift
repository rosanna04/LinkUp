//
//  ContentView.swift
//  LinkUp
//
//  Created by Rosanna Petecca on 02/02/25.
//

import SwiftUI

struct ContentView: View {
    
    @State private var name: String = "" //To save name
    
    @State private var surname: String = "" //To save surname

    var body: some View {
        
        NavigationView { //To change view
            
            VStack (){
                
                Image("LinkUpLogo").resizable().frame(width: 155, height: 170).clipped().aspectRatio(contentMode: .fit)
                
                //Ask to insert your name
                
                    Text("Insert your name")
                    .font(.title).fontWeight(.semibold).padding()
                
                
                //Insert your name
                
                TextField("Name", text: $name)
                    .padding().fontWeight(.semibold)
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(25)
                    .padding(20)
                    .multilineTextAlignment(.center)
                
                //Ask to insert your surname
                
                Text("Insert your surname")
                    .font(.title).fontWeight(.semibold)
                
                
                // Insert your surname
                
                TextField("Surname", text: $surname)
                    .padding().fontWeight(.semibold)
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(25)
                    .padding(20)
                    .multilineTextAlignment(.center)
                
                
                // StartingView
                
                NavigationLink(destination: StartingView(name: name, surname: surname)) {
                    
                Text("Send")
                        .font(.title).bold()
                        .frame(width: 160, height: 60)
                        .background(Color(uiColor: UIColor(hex: "#5206c2")))
                        .foregroundColor(.white)
                        .cornerRadius(30).padding(50).shadow(radius: 10)
                    
                }
            }.padding()
        } //end NavStack
    }
}

#Preview {
    ContentView()
}
