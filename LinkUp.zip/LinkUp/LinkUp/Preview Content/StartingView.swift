//
//  LinkUpApp.swift
//  LinkUp
//
//  Created by Rosanna Petecca on 02/02/25.
//

import SwiftUI

struct StartingView: View {
    var name: String
    var surname: String

    var body: some View {
        
            VStack(alignment: .center) {
                
                Image("LinkUpLogo").resizable().frame(width: 155, height: 170).clipped().aspectRatio(contentMode: .fit)
                
                Spacer().padding(10)
                
                Text("Hello, \(name) \(surname)!")
                    .font(.largeTitle)
                    .foregroundStyle(Color(uiColor: UIColor(hex: "#5206c2")))
                    .bold() .multilineTextAlignment(.center)
                    .padding()
                
                Text("Let's start tracking your habits")
                    .font(.title2)
                    .bold()
                    .padding(.bottom, 10)
                
                Text("Create a New Habit").foregroundStyle(Color(uiColor: UIColor(hex: "#5206c2")))
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .padding(.top, 50)
                
                Spacer()

                NavigationLink(destination: ChooseHabits()) {
                    HStack {
                        Image(systemName: "plus")
                            .font(.title)
                            .foregroundColor(.white)
                            .bold()
                    }
                    .frame(width: 250, height: 250)
                    .background(Color(uiColor: UIColor(hex: "AC94FF")))
                    .cornerRadius(70)
                    .padding()
                    .shadow(radius: 10)
                }

                Spacer()
            }
            .padding()
        }
    }


struct StartingView_Previews: PreviewProvider {
    static var previews: some View {
        StartingView(name: "User", surname: "Persona")
    }
}
