//
//  SwiftUIView.swift
//  LinkUp
//
//  Created by Rosanna Petecca on 04/02/25.
//

import SwiftUI

struct HabitChoosed: View {
    var body: some View {
        VStack {
           
            VStack {
                Text("Done!")
                    .foregroundStyle(Color(uiColor: UIColor(hex: "#5206c2")))
                    .font(.largeTitle)
                    .fontWeight(.bold)

                Text("Let's track your habits")
                    .foregroundStyle(.black)
                    .font(.title)
                    .fontWeight(.bold)
            }
            .padding()

            ScrollView {
                HomeView()
                    .padding()
            }
        }
    }
}

#Preview {
    HabitChoosed()
}


