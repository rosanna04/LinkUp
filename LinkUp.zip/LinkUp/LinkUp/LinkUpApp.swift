//
//  LinkUpApp 3.swift
//  LinkUp
//
//  Created by Rosanna Petecca on 03/02/25.
//

import SwiftUI

@main

struct LinkUpApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

#Preview{
    ContentView()
}
